package com.morris.mms.mms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
